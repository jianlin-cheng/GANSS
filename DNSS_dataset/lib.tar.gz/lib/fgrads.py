import numpy as np
from Time import start_watch, stop_watch
from numpy import *
# ID: %#9537108e9a 


def pack_weights_n_bias(*args):
   """ 
   Pack weights n biases into a 1d array.  Return the array and dimensions vector
   Order is important and assuming that we are getting w1, w1_bias, w2, w2_bias,
   etc.
   """

   if(len(args) >= 2 and len(args) % 2 == 0):
      dims = np.zeros((1,len(args)/2+1), dtype=int).flatten()
      dims[0] = args[0].shape[0]
      for i in range(0,len(args)/2):
          dims[i+1] = args[2*i].shape[1]

     
      size = 0;
      for i in range(0,len(args)):
          size += (args[i].shape[0] * args[i].shape[1])        

      package = np.zeros(size)
      offset = 0;
      package[0:(dims[0]*dims[1])] = np.reshape(args[0],(1, dims[0]*dims[1]))
      offset += dims[0]*dims[1]
      package[offset:offset+(dims[1])] = np.reshape(args[1], (1, dims[1]))
      offset += dims[1]

      for i in range(2,len(args),2):
          package[offset:offset+(dims[i/2]*dims[i/2+1])] = np.reshape(args[i],(1, dims[i/2]*dims[i/2+1]))
          offset += (dims[i/2]*dims[i/2+1])
          package[offset:offset+(dims[i/2+1])] = np.reshape(args[i+1], (1, dims[i/2+1]))
          offset += dims[i/2+1]

      return (package, dims)

   else:
      return ([], [])

def unpack_weights_n_bias(W, dims):
    """
    Unpack weights and biases contained in a weight vector, dims vector should be 
    formatted in a way similiar to pack_weights_n_biases fn
    """

    wb = []
    wb.append(W[0:dims[0]*dims[1]].reshape(dims[0],dims[1]))
    offset = dims[0]*dims[1]
    wb.append(W[offset:offset+dims[1]].reshape(1,dims[1]))
    offset += dims[1];

    for i in range(2, 2*(dims.shape[0]-1), 2):
       wb.append(W[offset:offset+dims[i/2]*dims[i/2+1]].reshape(dims[i/2], dims[i/2+1]))
       offset += (dims[i/2] * dims[i/2+1])
       wb.append(W[offset:offset+dims[i/2+1]].reshape(1, dims[i/2+1]))
       offset += dims [i/2+1];

    return wb
    
def f_cent_1_layer_disc(W, X, targets):
    """
    Calculated objective function for 1 layer (ie, no hidden layer)
    discrimenator using cross entropy error.  W is a weight vector
    were the very last weight is taken to be the bias, X is a matrix
    of inputs for weights where each row is an example.  Targets is a
    1d array of 0s or 1s for class/target, should have same size as 
    number of examples (ie, X.shape[0])
    """

    w = W[0:len(W)-1]
    b = W[len(W)-1]

    curr_probs = 1. / (1 + np.exp(-(np.dot(X,w)+b)))
    newtargs = targets[ : ,0]

    diff_sq = (newtargs-curr_probs)**2

    # f = MSE = 1/n * sum (y-t)^2 deriv 1/n sum 2(y-t)
    f = diff_sq.sum(axis=0)/targets.shape[0] #sum of errors divided by number

    return f


def grad_cent_1_layer_disc(W, X, targets):
    """
    Calculate the partial deriviates for 1 layer discrimenator using cross entropy error
    W is a weight vector where the last element is the bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a 
    column vector of 0s or 1s for class/target
    """

    w = W[0:len(W)-1]
    b = W[len(W)-1]

    curr_probs = 1. / (1 + np.exp(-(np.dot(X,w)+b)))
    curr_probs.resize(curr_probs.shape[0],1)
    delta = (curr_probs-targets)/X.shape[0]

    partials = np.dot(X.T, delta)
    partials = np.append(partials, np.dot(np.ones(X.shape[0]), delta))

#    newtargs = targets[:,0]
#    partials = 2*(newtargs-curr_probs).sum()/targets.shape[0]
    return partials

def f_cent_disc(W, dims, X, targets):
    """
    Calculate objective function for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is an 1d 
    numpy.ndarray of 0s or 1s for class/target 
    """
    print "Entering f_cent_disc: fgrads ln 124"
    exit(-1)

#    if(len(targets.shape) != 1): 
 #       print "Error, targets should be passed as 1d array"
  #      return []
    
    wb = unpack_weights_n_bias(W, dims)

    curr_probs = X
    for i in range(0,len(wb),2):
        next_probs = 1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1])))
        curr_probs = next_probs

    # Recast curr_probs as a 1d array to work with calc below since targets is a 1d arragy
    curr_probs = curr_probs[:,0]

    # objective fn is -t ln y - (1-t) ln (1-y) with derv. (y - t) 
    f = -(np.multiply(targets,np.log(curr_probs)) + np.multiply((1-targets), np.log(1-curr_probs))).sum()
    
    return f    

def grad_cent_disc(W, dims, X, targets):
    """
    Calculate the partial deriviates for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a 1d array
    of 0s or 1s for class/target 
    """
    print "Entering grad_cent_disc: fgrads ln 153"
    exit(-1)
 
#    if(len(targets.shape) != 1): 
#        print "Error, targets should be passed as 1d array"
#        return []

    # Check to make sure that targets was 1d but now make it a 2d, so that
    # matrix ops work below
 
    targets = np.reshape(targets,(targets.size,1))

    wb = unpack_weights_n_bias(W, dims)

    probs = []
    curr_probs = X
    probs.append(X)
    for i in range(0,len(wb),2):
        probs.append(1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1]))))
        curr_probs = probs[len(probs)-1]

    # Calculate intermediates and partials, highest level represented by curr_probs   
    deltas = []
    deltas.append(curr_probs - targets)

    dws = []

    # Compute the bias to the last layer, to make pack/unpack work, the
    # output must be reshaped from a 1d value to 2d 1x1 matrix
    dws.append(np.reshape(np.dot(np.ones(X.shape[0]).T, deltas[0]),(1,1)))
    dws.insert(0, np.dot(probs[len(probs)-2].T, deltas[0]))

    # in loop, assuming inserting deltas at front of list
    # loop index will be an offset from the end
    for i in range(1, len(probs)-1):

        tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, deltas[0]))
        dws.insert(0, np.dot(probs[len(probs)-2-i].T, deltas[0]))
    
    (partials, dims) = pack_weights_n_bias(*dws)
    return partials

def f_cent_1_layer_vect(W, dims, X, targets):
    """
    Calculated objective function for 1 layer (ie, no hidden layer)
    discrimenator using cross entropy error.  W is a weight vector
    were the very last weight is taken to be the bias, X is a matrix
    of inputs for weights where each row is an example.  Targets is a
    matrix of 0s or 1s for class/target, each row is considered a target
    and the number of rows should have same size as number of examples 
    (ie, X.shape[0]).  dims provides the dimensions of the W vector
    """

    wb = unpack_weights_n_bias(W, dims)

    w = wb[0]
    b = wb[1]

    curr_probs = 1. / (1 + np.exp(-(np.dot(X,w)+b)))

    # Calculate error using cross entropy error, sanitizing curr_probs and 1-curr_probs to make sure 
    # we don't take logs of negatives

    one_minus_curr_probs = (1-curr_probs)
    one_minus_curr_probs = one_minus_curr_probs + (1e-300 * (one_minus_curr_probs < 1e-300))
    curr_probs = curr_probs + (1e-300 * (curr_probs < 1e-300))

    # Calculate error using cross entropy error   
    f = -( np.multiply(targets, np.log(curr_probs)) + np.multiply((1-targets), np.log(one_minus_curr_probs))).sum()/targets.shape[0]

    return f

def grad_cent_1_layer_vect(W, dims, X, targets):
    """
    Calculate the partial deriviates for 1 layer discrimenator using cross entropy error
    W is a weight vector where the last element is the bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a 
    matrix where each row represents a target vector of 0s or 1s, dims are the 
    dimensions of the W vector
    """
   
    wb = unpack_weights_n_bias(W, dims)

    w = wb[0]
    b = wb[1]

    curr_probs = 1. / (1 + np.exp(-(np.dot(X,w)+b)))

    delta = (curr_probs - targets)/targets.shape[0]
    dws = []
    dws.append(np.dot(np.ones(X.shape[0]).T, delta))
    dws.insert(0, np.dot(X.T, delta))

    # Pack partials manually since pack_weights_n_bias needs atleast 2 layers
    package = np.zeros(dims[0]*dims[1]+dims[1])
    offset = 0;
    package[0:(dims[0]*dims[1])] = np.reshape(dws[0],(1, dims[0]*dims[1]))
    offset += dims[0]*dims[1]
    package[offset:offset+(dims[1])] = np.reshape(dws[1], (1, dims[1]))

    return package

def f_cent_vect(W, dims, X, targets):
    """
    Calculate objective function for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a matrix 
    of 0s or 1s and each row represents a target
    """
    print "Entering f_cent_vect: fgrads ln 270"
    exit(-1)

    wb = unpack_weights_n_bias(W, dims)

    probs = []
    curr_probs = X
    probs.append(X)
    for i in range(0,len(wb),2):
        probs.append(1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1]))))
        curr_probs = probs[len(probs)-1]

    # Calculate error using cross entropy error, sanitizing curr_probs and 1-curr_probs to make sure
    # we don't take logs of negatives

    one_minus_curr_probs = (1-curr_probs)
    one_minus_curr_probs = one_minus_curr_probs + (1e-300 * (one_minus_curr_probs < 1e-300))
    curr_probs = curr_probs + (1e-300 * (curr_probs < 1e-300))

    # Calculate error using cross entropy error
    f = -( np.multiply(targets, np.log(curr_probs)) + np.multiply((1-targets), np.log(one_minus_curr_probs))).sum()/targets.shape[0]

    return f

def grad_cent_vect(W, dims, X, targets):
    """
    Calculate the partial deriviates for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a matrix
    of 0s or 1s and each row is a target 
    """
    print "Entering grad_cent_vect: fgrads ln 301"
    exit;

    wb = unpack_weights_n_bias(W, dims)

    probs = []
    curr_probs = X
    probs.append(X)
    for i in range(0,len(wb),2):
        probs.append(1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1]))))
        curr_probs = probs[len(probs)-1]

    # Calculate intermediates and partials, highest level represented by curr_probs   
    deltas = []
    deltas.append((curr_probs - targets)/targets.shape[0])

    dws = []

    # Compute the bias to the last layer, to make pack/unpack work, the
    # output must be reshaped from a 1d value to 2d 1x1 matrix
    dws.append(np.reshape(np.dot(np.ones(X.shape[0]).T, deltas[0]), (targets.shape[1],1)))
    dws.insert(0, np.dot(probs[len(probs)-2].T, deltas[0]))

    # in loop, assuming inserting deltas at front of list
    # loop index will be an offset from the end
    for i in range(1, len(probs)-1):

        tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, deltas[0]))
        dws.insert(0, np.dot(probs[len(probs)-2-i].T, deltas[0]))
    
    (partials, dims) = pack_weights_n_bias(*dws)
    return partials

def f_lin_autoenc(W, dims, X):
    """ 
    Calculates the output value for a multi layer autoencoder where the 
    middle layer is linear
    """

    wb = unpack_weights_n_bias(W, dims)

    # Determine how many layers we have, recall that (dims-1)/2 should be half
    # the number of layers.  So the number of levels up to mid should be
    # one less than that
    to_mid = (len(dims)-1)/2 - 1

    curr_probs = X
    for i in range(0,(2*to_mid),2):
        next_probs = 1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1])))
        curr_probs = next_probs

    # Handle linear middle
    next_probs = np.dot(curr_probs, wb[2*to_mid]) + wb[2*to_mid+1]
    curr_probs = next_probs

    for i in range(2*(to_mid+1), len(wb) ,2):
        next_probs = 1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1])))
        curr_probs = next_probs


    # Calculate error using cross entropy error, sanitizing curr_probs and 1-curr_probs to make sure 
    # we don't take logs of negatives

    one_minus_curr_probs = (1-curr_probs)
    one_minus_curr_probs = one_minus_curr_probs + (1e-300 * (one_minus_curr_probs < 1e-300))
    curr_probs = curr_probs + (1e-300 * (curr_probs < 1e-300))

    # Calculate error using cross entropy error   
    f = -( np.multiply(X, np.log(curr_probs)) + np.multiply((1-X), np.log(one_minus_curr_probs))).sum()/X.shape[0]

    return f


def grad_lin_autoenc(W, dims, X):
    """
    Calculated the partials for a multi layer autoencoder where the middle layer is
    linear
    """   

    wb = unpack_weights_n_bias(W, dims)
    # Determine how many layers we have, recall that (dims-1)/2 should be half
    # the number of layers.  So the number of levels up to mid should be
    # one less than that
    to_mid = (len(dims)-1)/2 - 1

    probs = []
    curr_probs = X
    probs.append(X)
    for i in range(0,(2*to_mid),2):
        next_probs = 1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1])))
        probs.append(next_probs)
        curr_probs = next_probs

    # Handle linear middle
    next_probs = np.dot(curr_probs, wb[2*to_mid])
    probs.append(next_probs)
    curr_probs = next_probs

    for i in range(2*(to_mid+1), len(wb) ,2):
        next_probs = 1. / (1 + np.exp(-(np.dot(curr_probs, wb[i]) + wb[i+1])))
        probs.append(next_probs)
        curr_probs = next_probs

    # Calculate intermediates and partials, highest level represented by curr_probs
    deltas = []
    deltas.append((curr_probs - X)/X.shape[0])

    dws = []

    # Compute the bias to the last layer, to make pack/unpack work, the
    # output must be reshaped from a 1d value to 2d 1x1 matrix

    dws.append(np.reshape(np.dot(np.ones(X.shape[0]).T, deltas[0]), (X.shape[1],1)))
#    print "i 0", dws[0].shape
    dws.insert(0, np.dot(probs[len(probs)-2].T, deltas[0]))
#    print "i 0", dws[0].shape

    # in loop, assuming inserting deltas at front of list
    # loop index will be an offset from the end
    for i in range(1, to_mid+1):

        tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, deltas[0]))
#        print "i ", i, dws[0].shape
        dws.insert(0, np.dot(probs[len(probs)-2-i].T, deltas[0]))
#        print "i ", i, dws[0].shape

    # Handle linear layer 

    tmp = np.dot(deltas[0], wb[len(wb)-(to_mid)*2-2].T)
    deltas.insert(0, tmp)

    dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, deltas[0]))
#    print "Mi ", to_mid+1, dws[0].shape
    dws.insert(0, np.dot(probs[len(probs)-2-to_mid+1].T, deltas[0]))
#    print "Mi ", to_mid+1, dws[0].shape

    # Handle rest of encoder
    for i in range(to_mid+2, len(probs)-1):

        tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, deltas[0]))
#        print "i ", i, dws[0].shape
        dws.insert(0, np.dot(probs[len(probs)-2-i].T, deltas[0]))
#        print "i ", i, dws[0].shape


    (partials, dims) = pack_weights_n_bias(*dws)
    return partials

def test_f_multi(W, dims, X):
    """
    Calculates a simple output for a 1-2-2-1 network with identity function for 
    activation, just to test grad_check.  For simplicity, assume wieghts are as
    follows
    idx   wght
    --    ---
    0     w^1_11
    1     w^1_12
    2     w^2_11
    3     w^2_12
    4     w^2_21
    5     w^2_22
    6     w^3_11
    7     w^3_21
    """
    
    f = 0
    for i in range(0,len(X)):

        f = f + W[6]*(W[2]*W[0]*X[i] + W[4]*W[1]*X[i]) + W[7]*(W[3]*W[0]*X[i] + W[5]*W[1]*X[i])
    
    return f

def test_grad_multi(W, dims, X):
    """ 
    See encoding above
    """
    partials = np.zeros(8)


    for i in range(0,len(X)):
        partials[6] += W[2]*W[0]*X[i] + W[4]*W[1]*X[i]        
        partials[7] += W[3]*W[0]*X[i] + W[5]*W[1]*X[i]
        partials[5] += W[7] * W[1] * X[i] 
        partials[4] += W[6] * W[1] * X[i] 
        partials[3] += W[7] * W[0] * X[i] 
        partials[2] += W[6] * W[0] * X[i] 
        partials[0] += W[6]*W[2]*X[i] + W[7]*W[3]*X[i]        
        partials[1] += W[6]*W[4]*X[i] + W[7]*W[5]*X[i]
 
    return partials

   
#if __name__ == "__main__":
    
    

