import numpy as np
import cudamat as cm
from fgrads import pack_weights_n_bias, unpack_weights_n_bias
from Time import start_watch, stop_watch
# ID: %#937108e9ax 

def cuda_f_cent_disc(W, dims, X, targets):
    """
    CUDAMatrixized version of regular f_cent_disc, make sure to initialize
    cudamat before calling...

    Calculate objective function for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is an 1d 
    numpy.ndarray of 0s or 1s for class/target 
    """

#    if(len(targets.shape) != 1): 
#        print "Error, targets should be passed as 1d array"
#        return []
    
    wb = unpack_weights_n_bias(W, dims)

    cm_wb = []
    # Load weights/data onto card
    for i in range(0, len(wb)):
        cm_wb.append(cm.CUDAMatrix(wb[i]))    

    cm_curr_probs = cm.CUDAMatrix(X)
    for i in range(0, len(wb),2):
        next_probs = cm.dot(cm_curr_probs, cm_wb[i])  
        next_probs.add_row_vec(cm_wb[i+1])
        next_probs.apply_sigmoid()
        cm_curr_probs = next_probs
     
    # Recast curr_probs as a 1d array to work with calc below since targets is a 1d arragy
    curr_probs = cm_curr_probs.asarray()

    diff_sq = (targets-curr_probs)**2

    f = diff_sq.sum(axis=0)/targets.shape[0]
    return f[0]

def cuda_grad_cent_disc(W, dims, X, targets):
    """
    CUDAMatrixized version of regular grad_cent_disc, make sure to initialize
    cudamat before calling...

    Calculate the partial deriviates for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a 1d array
    of 0s or 1s for class/target 
    """
 
#    if(len(targets.shape) != 1): 
#        print "Error, targets should be passed as 1d array"
#        return []

    # Check to make sure that targets was 1d but now make it a 2d, so that
    # matrix ops work below
 
    targets = np.reshape(targets,(targets.size,1))
    cm_targets = cm.CUDAMatrix(targets)

    wb = unpack_weights_n_bias(W, dims)
    # Load weights/data onto card
    cm_wb = []
    for i in range(0, len(wb)):
        cm_wb.append(cm.CUDAMatrix(wb[i]))    
       
    cm_probs = []
    cm_curr_probs = cm.CUDAMatrix(X)
    
    cm_probs.append(cm_curr_probs)
    for i in range(0,len(wb),2):
        next_probs = cm.dot(cm_curr_probs, cm_wb[i])  
        next_probs.add_row_vec(cm_wb[i+1])
        next_probs.apply_sigmoid()
        cm_curr_probs = next_probs
        cm_probs.append(next_probs) 

    # Calculate intermediates and partials, highest level represented by curr_probs   
    cm_deltas = []
    cm_curr_probs.subtract(cm_targets)
    cm_deltas.append(cm_curr_probs)

    dws = []

    # Compute the bias to the last layer, to make pack/unpack work, the
    # output must be reshaped from a 1d value to 2d 1x1 matrix
    dws.append(np.reshape(np.dot(np.ones(X.shape[0]).T, cm_deltas[0].asarray()),(1,1)))
    dws.insert(0, cm.dot(cm_probs[len(cm_probs)-2].T, cm_deltas[0]).asarray())

    # in loop, assuming inserting deltas at front of list
    # loop index will be an offset from the end
    for i in range(1, len(cm_probs)-1):

        tmp = cm.dot(cm_deltas[0], cm_wb[len(cm_wb)-(i-1)*2-2].T)
        cm_probs[len(cm_probs)-1-i].copy_to_host()
        act_dw = cm.CUDAMatrix(cm_probs[len(cm_probs)-1-i].numpy_array)
        act_dw.subtract(1)
        act_dw.mult(-1)
        act_dw.mult(cm_probs[len(cm_probs)-1-i])
        cm_deltas.insert(0, tmp.mult(act_dw))

        #tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        #act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        #deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, cm_deltas[0].asarray()))
        dws.insert(0, cm.dot(cm_probs[len(cm_probs)-2-i].T, cm_deltas[0]).asarray())
   
    (partials, dims) = pack_weights_n_bias(*dws)
    partials = partials/X.shape[0]
    return partials


def cuda_f_cent_vect(W, dims, X, targets):
    """
    CUDAMatrixized version of regular f_cent_vect, make sure to initialize
    cudamat before calling...

    Calculate objective function for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is an matrix
    of 0s or 1s where each row is a target 
    """

    wb = unpack_weights_n_bias(W, dims)

    cm_wb = []
    # Load weights/data onto card
    for i in range(0, len(wb)):
        cm_wb.append(cm.CUDAMatrix(wb[i]))    

    cm_curr_probs = cm.CUDAMatrix(X)
    for i in range(0, len(wb),2):
        next_probs = cm.dot(cm_curr_probs, cm_wb[i])  
        next_probs.add_row_vec(cm_wb[i+1])
        next_probs.apply_sigmoid()
        cm_curr_probs = next_probs

    # Recast curr_probs as a 1d array to work with calc below since targets is a 1d arragy
    curr_probs = cm_curr_probs.asarray()
    curr_probs = np.reshape(curr_probs,(targets.shape[0], targets.shape[1]))
     
    # Calculate error using cross entropy error, sanitizing curr_probs and 1-curr_probs to make sure
    # we don't take logs of negatives
    
    one_minus_curr_probs = (1-curr_probs)
    one_minus_curr_probs = one_minus_curr_probs + (1e-300 * (one_minus_curr_probs < 1e-300))
    curr_probs = curr_probs + (1e-300 * (curr_probs < 1e-300))

    if (X.shape[0]==0): return 0

    # objective fn is -t ln y - (1-t) ln (1-y) with derv. (y - t) 
    f = -(np.multiply(targets,np.log(curr_probs)) + np.multiply((1-targets), np.log(one_minus_curr_probs))).sum()/X.shape[0]
    
    return f    

  
def cuda_grad_cent_vect(W, dims, X, targets):
    """
    CUDAMatrixized version of regular grad_cent_vect, make sure to initialize
    cudamat before calling...

    Calculate the partial deriviates for a discrimenator using cross entropy error
    W is a weight vector packed by pack_weights_n_bias, X is a matrix of 
    inputs for weights where each row is an example.  Targets is a matrix
    of 0s or 1s where each row is a target example
    """
 
    cm_targets = cm.CUDAMatrix(targets)

    wb = unpack_weights_n_bias(W, dims)
    # Load weights/data onto card
    cm_wb = []
    for i in range(0, len(wb)):
        cm_wb.append(cm.CUDAMatrix(wb[i]))    
       
    cm_probs = []
    cm_curr_probs = cm.CUDAMatrix(X)
    cm_probs.append(cm_curr_probs)
    for i in range(0,len(wb),2):
        next_probs = cm.dot(cm_curr_probs, cm_wb[i])  
        next_probs.add_row_vec(cm_wb[i+1])
        next_probs.apply_sigmoid()
        cm_curr_probs = next_probs
        cm_probs.append(next_probs) 

    # Calculate intermediates and partials, highest level represented by curr_probs   
    cm_deltas = []
    cm_curr_probs.subtract(cm_targets)
    cm_curr_probs.divide(X.shape[0])
    cm_deltas.append(cm_curr_probs)

    dws = []

    # Compute the bias to the last layer, to make pack/unpack work, the
    # output must be reshaped from a 1d value to 2d 1x1 matrix
    dws.append(np.reshape(np.dot(np.ones(X.shape[0]).T, cm_deltas[0].asarray()),(targets.shape[1],1)))
    dws.insert(0, cm.dot(cm_probs[len(cm_probs)-2].T, cm_deltas[0]).asarray())

    # in loop, assuming inserting deltas at front of list
    # loop index will be an offset from the end
    for i in range(1, len(cm_probs)-1):

        tmp = cm.dot(cm_deltas[0], cm_wb[len(cm_wb)-(i-1)*2-2].T)
        cm_probs[len(cm_probs)-1-i].copy_to_host()
        act_dw = cm.CUDAMatrix(cm_probs[len(cm_probs)-1-i].numpy_array)
        act_dw.subtract(1)
        act_dw.mult(-1)
        act_dw.mult(cm_probs[len(cm_probs)-1-i])
        cm_deltas.insert(0, tmp.mult(act_dw))

        #tmp = np.dot(deltas[0], wb[len(wb)-(i-1)*2-2].T)
        #act_dw = np.multiply(probs[len(probs)-1-i], (1-probs[len(probs)-1-i]))
        #deltas.insert(0, np.multiply(tmp, act_dw))

        dws.insert(0, np.dot(np.ones((X.shape[0],1)).T, cm_deltas[0].asarray()))
        dws.insert(0, cm.dot(cm_probs[len(cm_probs)-2-i].T, cm_deltas[0]).asarray())
   
    (partials, dims) = pack_weights_n_bias(*dws)
    return partials


