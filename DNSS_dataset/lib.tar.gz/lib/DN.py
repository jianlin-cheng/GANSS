import numpy as np
import pickle

class DN:
    """ Represents a Deep Network and related training and test procedures. 

    Attributes:
        layer_count    The number of layers in the network, including input
        weights        An array of weights for each layer based on node type
        params         An array of learning parameters for each layer 
        arch           An array of node_count and node_type for each layer

        Note that the weights and parameters begin indexing at 1, arch from 0
        with zero being the data/input layer.


    TODO:
       LEGACY - Set card to use
       Functions to save/load a model to a file in a binary format
       Training and testing functions that use an abstracted layer/interface
       Functions to reinitialize learning parameters based on architecture
       Function to randomly initialize weights
       Function to do adjust using backprob (for finetuning or learning NN)

    """ 

    layer_count = 0       
    weights = []
    params = []
    arch = []
    legacy_card_number = 0     

    def __init__(self, arch_specifier):
        """ Initialize a DN from an architecture specification. 

        The architecture specifier is a list with node counts by layer and
        optionally followed by node type ('S': sigmoid (default), '-': data).
        The learning parameters will also be set to default values based on 
        the node type.  The last layer should be the size of the target or
        target vector.


        """

        self.layer_count = 1
        self.arch=[]
        self.weights=[]
        self.params=[]
        self.arch.append({'node_type': '-', 'node_count': 0})
        self.weights.append(dict())  # Set with dummy value
        self.params.append(dict())   # Set with dummy value
        for value in arch_specifier:
            if type(value) is int:
                self.arch.append({'node_type': 'S', 'node_count': value})
                self.layer_count = self.layer_count + 1
            if type(value) is str:
                if value.upper() == 'S':
                    if self.layer_count > 0:
                        self.arch[(self.layer_count-1)]['node_type'] = value.upper()

                else:
                    print "Invalid node type encountered (%s).  Will " % value,
                    print "use a default node type for this layer ",
                    print "(%d)" % self.layer_count

        print "\n-----------------------------------------"
        for i in range(1, self.layer_count):  
            print "Setting up weights for layer %d," % i,
            print "node type is %s." % self.arch[i]['node_type']
            if self.arch[i]['node_type'] == 'S':
                self.weights.append({'w': 0, 'vb': 0, 'hb': 0})
                self.params.append({'batch_size': 1000, 'num_epochs': 20, 
                                    'final_momentum': 0.9, 
                                    'initial_momentum': 0.5, 
                                    'weight_cost': 0.0002, 'epsilon': 0.1 })
        print "-------------------------------------------\n"
    

    def train_cuda_legacy(self, training_features, targets):
	from Time import start_watch, stop_watch

        if targets.ndim == 1 and self.arch[self.layer_count-1]['node_count'] != 1:
            print "Error: Model architecture is not compatible with a binary ",
            print "classifier.  "
            exit(-1) 
        
        if targets.ndim > 1 and \
          targets.shape[1] is not self.arch[self.layer_count-1]['node_count']:
            print "Error: Final layer size and target size are not the same."
            print targets.ndim, targets.shape, self.arch[self.layer_count-1]['node_count']
            exit(-1)

        import cudamat as cm
        from rbm_cudamat import rbm, calc_hidden_probs
        from fgrads import f_cent_1_layer_disc, grad_cent_1_layer_disc, f_cent_1_layer_vect, grad_cent_1_layer_vect, pack_weights_n_bias, unpack_weights_n_bias, f_cent_disc, grad_cent_disc
        from cuda_fgrads import cuda_f_cent_vect, cuda_grad_cent_vect, cuda_f_cent_disc, cuda_grad_cent_disc 
        from minimize import minimize

        cm.cublas_init()
        cm.CUDAMatrix.init_random(1)

        if self.legacy_card_number != 0:
            cm.cuda_set_device(self.legacy_card_number)

        self.arch[0]['node_count'] = training_features.shape[1]
        data = training_features

        for i in range(1, self.layer_count-1):
            print "Training layer %d, %d -> %d" % (i, self.arch[i-1]['node_count'], self.arch[i]['node_count'])        
            (w, vb, hb) = rbm(data, self.arch[i]['node_count'], self.params[i]['batch_size'], self.params[i]['num_epochs'], epsilon=self.params[i]['epsilon'])
            self.weights[i]['w'] = w
            self.weights[i]['vb'] = vb
            self.weights[i]['hb'] = hb
            data = calc_hidden_probs(data, w, hb, self.params[i]['batch_size'])


        # Add the top classification layer
	print "Adding the top classification layer:"
        idx = self.layer_count-1
        dims = np.zeros(2)    # For legacy pack, unpack code used in grad,
                              # f_grad, etc, this must be a np.ndarray 
        dims[0] = self.arch[idx - 1]['node_count']
        dims[1] = self.arch[idx]['node_count']
        print dims
        w = np.zeros(dims[0] * dims[1] + dims[1])

        batch_size = self.params[idx]['batch_size']
        self.weights[idx]['w'] = np.random.randn(data.shape[1] , self.arch[idx]['node_count'])
        self.weights[idx]['hb'] = np.random.randn(1, self.arch[idx]['node_count'])

        for epoch in range(1, self.params[idx]['num_epochs']): 

            for i in range(0, data.shape[0]/batch_size):
                if targets.ndim > 1 and targets.shape[1] > 1:
                    batch_targets = targets[batch_size*i:batch_size*(i+1),:]
                    batch_data = data[batch_size*i:batch_size*(i+1),:]
 
                    # Pack top layer weights, manually 
                    w[0:dims[0]*dims[1]] = np.reshape(self.weights[idx]['w'], (1, dims[0]*dims[1]))
                    w[(dims[0]*dims[1]):dims[0]*dims[1]+dims[1]] = np.reshape(self.weights[idx]['hb'],(1,dims[1])) 

                    args = (dims, batch_data, batch_targets)
                    r_val = minimize(w, f_cent_1_layer_vect, grad_cent_1_layer_vect, args, maxnumlinesearch=3, verbose=False)

                    w = r_val[0]
                    self.weights[idx]['w'] = w[0:dims[0]*dims[1]].reshape(dims[0], dims[1])
                    self.weights[idx]['hb'] = w[dims[0]*dims[1]:dims[0]*dims[1]+dims[1]].reshape(1, dims[1])

                else:
                    batch_targets = targets[batch_size*i:batch_size*(i+1)]
                    batch_data = data[batch_size*i:batch_size*(i+1)]
 
                    # Pack top layer weights, manually 
                    w[0:dims[0]*dims[1]] = np.reshape(self.weights[idx]['w'], (1, dims[0]*dims[1]))
                    w[(dims[0]*dims[1]):dims[0]*dims[1]+dims[1]] = np.reshape(self.weights[idx]['hb'],(1,dims[1])) 
                   
                    args = (batch_data, batch_targets)
                    r_val = minimize(w, f_cent_1_layer_disc, grad_cent_1_layer_disc, args, maxnumlinesearch=3, verbose=False)  

                    w = r_val[0]
                    self.weights[idx]['w'] = np.reshape(w[0:dims[0]*dims[1]],(dims[0],dims[1]))
                    self.weights[idx]['hb'] = np.reshape(w[dims[0]*dims[1]:dims[0]*dims[1]+dims[1]], (1,1))

        print "Fine tuning the weights..."

        # Now fine tune with backprop entire network 
        batch_size = 1000
        for epoch in range(0, 10):

            print str(epoch+1) + ".."

            for i in range(0, training_features.shape[0]/batch_size):
                if targets.ndim > 1 and targets.shape[1] > 1:

                    batch_targets = targets[batch_size*i:batch_size*(i+1),:]
                    batch_data = training_features[batch_size*i:batch_size*(i+1),:]

                    (w, dims) = self.pack_weights()
                    args = (dims, batch_data, batch_targets)

                    r_val = minimize(w, cuda_f_cent_vect, cuda_grad_cent_vect, args, maxnumlinesearch=3,verbose=True)
                    package = r_val[0]
                    self.unpack_weights(package) 

                # Handle descrimiator case
                else:

                    batch_targets = targets[batch_size*i:batch_size*(i+1)]
                    batch_data = training_features[batch_size*i:batch_size*(i+1)]

                    (w, dims) = self.pack_weights()
                    args = (dims, batch_data, batch_targets)

                    r_val = minimize(w, cuda_f_cent_disc, cuda_grad_cent_disc, args, maxnumlinesearch=3,verbose=True)
                    package = r_val[0]

                    self.unpack_weights(package) 

        print ""

        cm.cublas_shutdown()


    def adjust_with_backprop_legacy(self, training_features, targets, 
      num_epochs, batch_size):
  
        # Sanity check between target dims and output layer
        if targets.ndim == 1 and self.arch[self.layer_count-1]['node_count'] != 1:
            print "Error: Model architecture is not compatible with a binary ",
            print "classifier.  "
            exit(-1)

        if targets.ndim > 1 and \
          targets.shape[1] is not self.arch[self.layer_count-1]['node_count']:
            print "Error: Final layer size and target size are not the same."
            print targets.ndim, targets.shape, self.arch[self.layer_count-1]['node_count']
            exit(-1)

        import cudamat as cm
        from rbm_cudamat import rbm, calc_hidden_probs
        from fgrads import f_cent_1_layer_disc, grad_cent_1_layer_disc, f_cent_1_layer_vect, grad_cent_1_layer_vect, pack_weights_n_bias, unpack_weights_n_bias, f_cent_disc, grad_cent_disc
        from cuda_fgrads import cuda_f_cent_vect, cuda_grad_cent_vect, cuda_f_cent_disc, cuda_grad_cent_disc
        from minimize import minimize

        cm.cublas_init()
        cm.CUDAMatrix.init_random(1)

        if self.legacy_card_number != 0:
            cm.cuda_set_device(self.legacy_card_number)    

        self.arch[0]['node_count'] = training_features.shape[1]
        data = training_features

        # Check if weights exists.  If not, do a random initialization.
        for i in range(1, self.layer_count):
            num_vis = self.arch[i-1]['node_count']
            num_hid = self.arch[i]['node_count']

            # Checks for sigmoid node
            if self.arch[i]['node_type'] == 'S':
                print "Checking weights for layer ", i, ".  Node type: S"
                if type(self.weights[i]['w']) != "numpy.ndarray" \
                  or self.weights[i]['w'].shape != (num_vis, num_hid):
                    self.weights[i]['w'] = 0.1 * np.random.randn(num_vis, num_hid)
                    print "  (re)initialized w."
                else:
                    print "  w: OK"

                if type(self.weights[i]['hb']) != "numpy.ndarray" \
                  or self.weights[i]['hb'].shape != (1, num_hid):
                    self.weights[i]['hb'] = 0.1 * np.random.randn(1, num_hid)
                    print "  (re)initialized hb"
                else:
                    print "  hb: OK"

                if type(self.weights[i]['vb']) != "numpy.ndarray" \
                  or self.weights[i]['vb'].shape != (1, num_vis):
                    self.weights[i]['vb'] = 0.1 * np.random.randn(1, num_vis)
                    print "  (re)initialized vh"
                else:
                    print "  vb: OK"

            else:
                print "ERROR: Unknown or invalid node type at layer ", i, "."


        # Now fine tune with backprop entire network 
        for epoch in range(0, num_epochs):

            print str(epoch+1) + "..",

            for i in range(0, training_features.shape[0]/batch_size):

                if targets.ndim > 1 and targets.shape[1] > 1:

                    batch_targets = targets[batch_size*i:batch_size*(i+1),:]
                    batch_data = training_features[batch_size*i:batch_size*(i+1),:]

                    (w, dims) = self.pack_weights()
                    args = (dims, batch_data, batch_targets)

                    r_val = minimize(w, cuda_f_cent_vect, cuda_grad_cent_vect, args, maxnumlinesearch=3,verbose=False)
                    package = r_val[0]
                    self.unpack_weights(package) 



                # Handle descrimiator case
                else:

                    batch_targets = targets[batch_size*i:batch_size*(i+1)]
                    batch_data = training_features[batch_size*i:batch_size*(i+1)]

                    (w, dims) = self.pack_weights()
                    args = (dims, batch_data, batch_targets)

                    r_val = minimize(w, cuda_f_cent_disc, cuda_grad_cent_disc, args, maxnumlinesearch=3,verbose=False)
                    package = r_val[0]
                    self.unpack_weights(package) 


        print ""

        cm.cublas_shutdown()

    def eval_cuda_legacy(self, test_features, targets):

        data = self.calc_output_legacy(test_features, 1000)

        if data.ndim > 1 and data.shape[1] > 1:
            out = np.zeros(data.shape)
            max = data.max(axis=1)

            for i in range(0,targets.shape[0]):
                out[i,:] = 1 * (data[i,:] > max[i] - 1e-5)

            tp = np.multiply(out, targets).sum()

            print ""
            print "* Percent correctly classified %.3f " % (1.0*tp/targets.shape[0])



        else:
            # Add test for binary case (ie, one value target)
            print "Sum of targets: " + str(targets.sum())
            correct = 0
            out = np.zeros(data.shape, dtype=int)
            for i in range(0, len(targets)):
                out[i] = 1 * (data[i] > 0.5)
                if(out[i] == targets[i]):
                    correct = correct + 1
            print "Sum of predictions: " + str(out.sum())
            print "Number of targets: " + str(targets.shape)

            print "",
            print "* Percent correctly classified %.3f " % (1.0*correct/len(targets))


    def test_cuda_legacy(self, test_features, targets):

        import cudamat as cm
        from rbm_numpy import calc_hidden_probs

        # Initialize CUDA
        cm.cublas_init()
        cm.CUDAMatrix.init_random(1)

        if self.legacy_card_number != 0:
            cm.cuda_set_device(self.legacy_card_number)    

        data = test_features

        for i in range(1, self.layer_count):
            data = calc_hidden_probs(data, self.weights[i]['w'], self.weights[i]['hb'])

        if data.ndim > 1 and data.shape[1] > 1:
            out = np.zeros(data.shape)
            max = data.max(axis=1)

            for i in range(0,targets.shape[0]):
                out[i,:] = 1 * (data[i,:] > max[i] - 1e-5)

            tp = np.multiply(out, targets).sum()

            print ""
            print "* Percent correctly classified %.3f " % (1.0*tp/targets.shape[0])



        else:
            # Add test for binary case (ie, one value target)
            print "Sum of targets: " + str(targets.sum())
            correct = 0
            out = np.zeros(data.shape, dtype=int)
            for i in range(0, len(targets)):
                out[i] = 1 * (data[i] > 0.5)
                if(out[i] == targets[i]):
                    correct = correct + 1
            print "Sum of predictions: " + str(out.sum())
            print "Number of targets: " + str(targets.shape)

            print "",
            print "* Percent correctly classified %.3f " % (1.0*correct/len(targets))

        cm.cublas_shutdown()

    def calc_output_legacy(self, data, batch_size):
        """ Calculate the output (probababilies) for a set of data

        The purpose of this function is to calculate the output of a DN on 
        some set of data.  The values will calculated using rbm_cudamat
        on slices of data specified by the batch size

        """ 

        import cudamat as cm
        import rbm_numpy, rbm_cudamat

        # Initialize CUDA
        cm.cublas_init()
        cm.CUDAMatrix.init_random(1)

        if self.legacy_card_number != 0:
            cm.cuda_set_device(self.legacy_card_number)    

        # Create output, use the size of the last layer to do this
        output = np.empty((data.shape[0], 
                           self.arch[(self.layer_count-1)]['node_count']))

        # Slice up data, handling batches of batch_size. USE INT DIVISION
        processed = 0
        for j in range(data.shape[0] // batch_size):

            curr_data = data[j*batch_size:(j+1)*batch_size,:]

            for i in range(1, self.layer_count):

                # Handle a sigmoid node
                if self.arch[i]['node_type'] == 'S':
                    curr_data = \
                      rbm_cudamat.calc_hidden_probs(curr_data, 
                                                    self.weights[i]['w'], 
                                                    self.weights[i]['hb'], 
                                                    batch_size) 

            output[j*batch_size:(j+1)*batch_size,:] = curr_data[:,:]
            processed = processed + batch_size


        # Now handle anything that was left over i.e., what didn't fit in
        if processed != data.shape[0]:
            
            curr_data = data[processed:,:]

            for i in range(1, self.layer_count):

                # Handle a sigmoid node
                if self.arch[i]['node_type'] == 'S':
                    curr_data = \
                      rbm_numpy.calc_hidden_probs(curr_data, 
                                                  self.weights[i]['w'], 
                                                  self.weights[i]['hb'])

            output[processed:,:] = curr_data[:,:]

        cm.cublas_shutdown()

        return output

    def set_cuda_legacy_card_number(self, number):
        """ Set the card number for cuda

        """

        self.legacy_card_number = number

    def pack_weights(self):
        """ Pack weights and biases into a 1-D array.

        The weights will be packed in starting from the first layer followed 
        by the biases.  If no biases are used for node type then zeros are
        filled in (ie, biases are always included).  A descriptor is also
        returned which is an array will all of the layer sizes.  Note that
        the 0 layer is the size of the input data
 

        """                                                                       

        if(self.layer_count > 1):
            dims = np.zeros((1, self.layer_count), dtype = int).flatten()
            for i in range(0,self.layer_count):
                dims[i] = self.arch[i]['node_count']

            size = 0
            for i in range(1, self.layer_count):
                if self.arch[i]['node_type'] == 'S':
                    size = size + self.weights[i]['w'].shape[0] \
                           * self.weights[i]['w'].shape[1]
                    size = size + self.weights[i]['hb'].shape[0] \
                           * self.weights[i]['hb'].shape[1]

            package = np.zeros(size)
            offset = 0
            package[0:(dims[0]*dims[1])] = np.reshape(self.weights[1]['w'],
                                                      (1, dims[0]*dims[1]))
            offset = offset + dims[0]*dims[1]
            package[offset:offset+dims[1]] = np.reshape(self.weights[1]['hb'],
                                                        (1, dims[1]))
            offset = offset + dims[1]
            for i in range(2,self.layer_count):
                package[offset:offset+(dims[i-1]*dims[i])] \
                 = np.reshape(self.weights[i]['w'], (1, dims[i-1]*dims[i]))
                offset = offset + dims[i-1]*dims[i]
                package[offset:offset+(dims[i])] \
                 = np.reshape(self.weights[i]['hb'], (1, dims[i]))
                offset = offset + dims[i]

            return (package, dims)

        else:
            return([], [])

    
    def unpack_weights(self, package):
        """ Unpack weights from a 1-D array dimensions of the packed contents.

        The weights from the package will be unpacked according to the DNs 
        architecture.  The weights of the DN will then be set to the contents
        of the package.


        """

        dims = np.zeros((1, self.layer_count), dtype = int).flatten()
        for i in range(0,self.layer_count):
            dims[i] = self.arch[i]['node_count']

        offset = 0
        for i in range(1, self.layer_count):
            if self.arch[i]['node_type'] == 'S':
                self.weights[i]['w'] \
                 = package[offset:offset+dims[i-1]*dims[i]].reshape(dims[i-1],
                                                                    dims[i])
                offset = offset + dims[i-1]*dims[i]
                self.weights[i]['hb'] \
                 = package[offset:offset+dims[i]].reshape(1, dims[i])
                offset = offset + dims[i]


    def set_param(self, key, value, layer=''):
        """ Set a parameter(s) to a specified value.
 
        If no layer is specified, all layers with the given key will be set
        to the specified value.  If not values were changed, a warning message
        is displayed indicating that the key was possibly misspelled or non
        existant.


        """

        update_count = 0

        if layer == '':
            for i in range(1, self.layer_count):
                if self.params[i].has_key(key):
                    self.params[i][key] = value
                    print "Setting %s to %s for layer %d" % (key, value, i)    
                    update_count = update_count + 1
        else:
	    if len(self.params) < layer and self.params[layer].has_key(key):
                self.params[layer][key] = value
                print "Setting %s to %s for layer %d" % (key, value, layer)
                update_count = update_count + 1    
 
        if update_count == 0:
            print "No parameters were updated.  Check key (%s) and layer ",
            print "if specified" % key
 

def DN_load(filename):
    """ Load the deep network and associated architecture and layer count

    The deep network and values needed for classification are loaded from
    the specified file location.  This is done using the pickle module.
    Note the learning parameters may or may not be not saved.

    Usage: dn = DN_load('model.dat')

    """

    fh = open(filename, 'r')
    obj = pickle.load(fh)
        
    return obj

    # TODO: do a check for the learning parameters and re-initalize if need be


def DN_save(obj, filename):
    """ Save the deep network and associated architecture and layer count

    The deep network and values needed for classification are dumped to 
    the specified file location.  This is done using the pickle module.
    Note the learning parameters may or may not be saved.

    Usage: DN_save(dn, 'model.dat')

    """ 

    fh = open(filename, 'w')
    pickle.dump(obj, fh)

if __name__ == "__main__":
    import sys, os

    if len(sys.argv) != 1:
         print "Usage: " + sys.argv[0]
         exit()

    try:
        import np_datasets
    
    except ImportError, e:

        NUMPY_DATASETS_PATH = "/home/jeickholt/sandbox/numpy-datasets"
        if os.path.exists(NUMPY_DATASETS_PATH):

            sys.path.append('/home/jeickholt/sandbox/numpy-datasets')
            try:
                import np_datasets
                pass 
            
            except ImportError, e:
                print "Couldn't import np_datasets."   
                exit(-1)

        else:
            print "Couldn't import np_datasets.  Check", NUMPY_DATASETS_PATH

    print "Binary classification task (traing using backprob)..."

    (data_l1, targets) = np_datasets.MNIST_01_training_data()
    dn = DN([20, 20, 1])

    dn.set_param('num_epochs', 3)
    dn.set_param('batch_size', 100)
   
    dn.adjust_with_backprop_legacy(data_l1, targets, 20, 1000)
   
    (data_test, targets) = np_datasets.MNIST_01_testing_data()
    dn.test_cuda_legacy(data_test, targets)
    dn.eval_cuda_legacy(data_test, targets)

    print "======"

    print "Binary classification task (DN)..."

    (data_l1, targets) = np_datasets.MNIST_01_training_data()

    dn = DN([20, 20, 1])
    dn.train_cuda_legacy(data_l1, targets)

    (data_test, targets) = np_datasets.MNIST_01_testing_data()

    dn.test_cuda_legacy(data_test, targets)

    print "======"

    print "Softmax classification task (training with backprob)..."

    (data_l1, labels) = np_datasets.MNIST_training_data()
    targets = np.zeros((labels.shape[0], 10 ), dtype=int)
    for i in range(0, labels.shape[0]):
        targets[i][labels[i]] = 1

    dn = DN([200, 200, 200, 200, 10])

    dn.adjust_with_backprop_legacy(data_l1, targets, 20, 1000)

    (data_l1, labels) = np_datasets.MNIST_testing_data()
    targets = np.zeros((labels.shape[0], 10 ), dtype=int)
    for i in range(0, labels.shape[0]):
        targets[i][labels[i]] = 1

    dn.test_cuda_legacy(data_l1, targets)
    dn.eval_cuda_legacy(data_l1, targets)

#*************************
    exit(1)
#*************************

    print "======"

    print "Softmax classification task (DN)..."

    (data_l1, labels) = np_datasets.MNIST_training_data()
    targets = np.zeros((labels.shape[0], 10 ), dtype=int)
    for i in range(0, labels.shape[0]):
        targets[i][labels[i]] = 1

    dn = DN([200, 200, 200, 200, 10])

    dn.set_param('num_epochs', 20)
    dn.set_param('batch_size', 100)
    dn.train_cuda_legacy(data_l1, targets)

    (data_l1, labels) = np_datasets.MNIST_testing_data()
    targets = np.zeros((labels.shape[0], 10 ), dtype=int)
    for i in range(0, labels.shape[0]):
        targets[i][labels[i]] = 1

    dn.test_cuda_legacy(data_l1, targets)

    print "====="

#    print "Trying with FM data"
#    (data_fm, targets) = np_datasets.FM_training_data()
#    dn = DN([20, 20, 1])
#    dn.train_cuda_legacy(data_fm, targets)

#    (data_fm, targets) = np_datasets.FM_testing_data()
#    dn.test_cuda_legacy(data_fm, targets)


